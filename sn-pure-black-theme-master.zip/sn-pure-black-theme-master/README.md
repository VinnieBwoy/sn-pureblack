# Pure Black Theme for Standard Notes

Theme for [Standard Notes](https://standardnotes.org/). Optimized for OLED devices such as iPhone X.

## Installation

Open "Extensions" in Standard Notes and click "Import Extension". Enter the following URL as Extension Link and press Enter:

```
https://listed.to/G4qnpftLNJ
```

## Preview

<img src="https://raw.githubusercontent.com/christianhans/sn-pure-black-theme/master/preview1.png" width="300px">  <img src="https://raw.githubusercontent.com/christianhans/sn-pure-black-theme/master/preview2.png" width="300px">
